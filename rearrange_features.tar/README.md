# RearrangeFeatures
Mod for Startup Company on Steam Workshop :
https://steamcommunity.com/sharedfiles/filedetails/?id=1737261285

--

Allows you to rearrange features of your websites.

[b][u]Don't forget to subscribe to "[url=https://steamcommunity.com/workshop/filedetails/?id=1737281395]Languages Module[/url]", this is a required item for this mod.[/u][/b]

Feel free to translate this mod to another language (or improve translation) on [url=https://app.localizor.io/game/4/translations]Localizor[/url].

Translations by :
- English : [url=https://steamcommunity.com/id/Nitrous77/]NiTroUs*[/url],
- French : [url=https://steamcommunity.com/id/Nitrous77/]NiTroUs*[/url],
- German : [url=https://steamcommunity.com/id/silverdroid]Silverdroid[/url],
- Italian : [url=https://steamcommunity.com/id/NiceDeveloper]NiceDeveloper(mariomarietto)[/url],
- Russian : [url=https://steamcommunity.com/id/dimon_7147]dimon_7147[/url], Redion, etsVlone

Thanks to :
- [url=https://steamcommunity.com/id/jhovgaard]jhovgaard[/url] for his amazing game (and future releases),
- [url=https://www.flaticon.com/authors/roundicons]Roundicons[/url] for the icon (licensed by [url=https://creativecommons.org/licenses/by/3.0/]Creative Commons BY 3.0[/url]),
- All translators (check credits above)


--

If any problems : @Azul#8005 at [url=https://discord.gg/hovgaardgames]discord.gg/hovgaardgames[/url]

Missing something in the description ? Tell me in the comments. :)