exports.initialize = (modPath) => {}
exports.onLoadGame = (settings) => {}
exports.onUnsubscribe = (done) => {}